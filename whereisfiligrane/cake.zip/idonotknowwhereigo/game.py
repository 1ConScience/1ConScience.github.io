from lvl1 import *

lvl1()
nettoyage()
